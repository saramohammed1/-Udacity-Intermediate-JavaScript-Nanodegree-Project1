// Create Dino Constructor
function Dino(species, weight, height, diet, where, when, fact, image) {
        this.species = species;
        this.weight = weight;
        this.height = height;
        this.diet = diet;
        this.where = where;
        this.when = when;
        this.fact = fact;
        this.image = image;
}

// Create Dino Objects
const dinoArray = Array();
function getDinoArray(dinos) {
    dinos.forEach((dino) => {
        newObj = new Dino(
            dino.species,
            dino.weight,
            dino.height,
            dino.diet,
            dino.where,
            dino.when,
            dino.fact,
         `./${dino.species.toLowerCase()}.png`
        )
        dinoArray.push(newObj);
    });
}

// Get data from JSON
fetch('./dino.json')
    .then(response => response.json())
    .then(data => { 
        getDinoArray(data.Dinos);
}).catch(error => console.log("there is an error here",error));

// Create human object
let human={
    species:"human",
    weight:Number(50),
    height:Number(5.5),
    diet:"omnivore",
    where:"worldwide",
    when:"now",
    fact:"Humans are the most inteligent species on the planet",
    image:"human.png"
   
}

// Get human data from form
    function getData() {
        let name = document.getElementById('name').value;
        let feet = parseFloat(document.getElementById('feet').value);
        let inches = parseFloat(document.getElementById('inches').value);
        let height = (feet * 12) + inches;
        let weight = parseFloat(document.getElementById('weight').value);
        let diet = document.getElementById('diet').value;
        human.species = name;
		human.weight = weight;
		human.height = height
		human.diet = diet;  
    };

// Generate human tile
function generateHumanTile(human){
        const tiledivv = document.createElement('div');
        tiledivv.classList.add('grid-item');
        tiledivv.innerHTML = 
            `<h3>${human.species}</h3>
           <img src="images/${human.image}">`; 
     tiledivv.innerHTML += `<p>${human.fact}</p>`;
    return tiledivv;
      
};

// Create Dino Compare Method 1
// // NOTE: Weight in JSON file is in lbs, height in inches. 
    
    function compareWeight(dino){
        let humanWeight=Number(human.weight);
        let dinoWeight=Number(dino.weight);
        if(humanWeight>dinoWeight){
            return `You Are Heavier Than ${dino.species}`;
        }
        else{
            return`You Are Lighter Than ${dino.species}`
        }
}
  
// Create Dino Compare Method 2
// // NOTE: Weight in JSON file is in lbs, height in inches.
    function compareHeight(dino){
        let humanHeight=Number(human.height);
        let dinoHeight=Number(dino.height);
        if(humanHeight>dinoHeight){
            return `You Are Taller Than ${dino.species}`
        }
        else if (humanHeight<dinoHeight){
            return `You Are Shorter Than ${dino.species}`
        }
        else{
            return 'You Both Have The Same Hight'
        }
}

// Create Dino Compare Method 3
// // NOTE: Weight in JSON file is in lbs, height in inches.

    function compareDiet(dino) {
        let humanDiet=Number(human.diet);
        let dinoDiet=Number(dino.diet);
        if (dinoDiet=== humanDiet) {
            return `Like you, ${dino.species} had ${dino.diet} diet`
        } else {
            return `Unlike you, ${dino.species} had ${dino.diet} diet`
        }
    }


// Generate Tiles for each Dino in Array
     function generateTile(){ 
        const tile=dinoArray.map((dino) => {
        const tilediv = document.createElement('div');
        tilediv.classList.add('grid-item');
        tilediv.innerHTML = `
        <h3>${dino.species}</h3>
        <img src="images/${dino.image}">`;
        if (dino.species !== "Pigeon") {
            tilediv.innerHTML += (()=> {
				let result = "";
				const randomcase = getRandomInt(5);

				switch (randomcase) {
					case 1:
						result =`<p>${compareHeight(dino)} </p>`; 
						break;
					case 2:
						result = `<p>${compareWeight(dino)} </p>`;
						break;
					case 3:
						result = `<p>${compareDiet(dino)} </p>`;
						break;
					case 4:
						result = `<p>The ${dino.species} lived in what is now ${dino.where}.</p>`;
						break;
					case 5:
						result = `<p>The ${dino.species} was found in the ${dino.when}.</p>`;
						break;
					default:
						result = `<p>The ${dino.fact} </p>`;
						break;
				}
				return result;
			})();
		}
        else if (dino.species === "Pigeon") {
            tilediv.innerHTML +=`<p>${dino.fact}</p>`;
        }
              return tilediv;
       })
        
    return tile;
      } 

// Show tiles to the DOM
function grid (){
    const grid = document.getElementById('grid');
    let b= generateTile();
    let a=generateHumanTile(human);
    let start = 4;
    let deleteCount = 0;
    b.splice(start, deleteCount, a);
    b.forEach(el=>grid.appendChild(el));

}
// Used in generateTile function
    function getRandomInt(max) {
     return Math.floor(Math.random() * max);
    }

// Remove form from screen
function remove(){
document.getElementById('dino-compare').innerHTML = "";
}

// On button click, prepare and display infographic

const compareBtn =document.getElementById("btn");
compareBtn.addEventListener("click", ()=>{
    getData();
    grid();
    remove();
}
    );